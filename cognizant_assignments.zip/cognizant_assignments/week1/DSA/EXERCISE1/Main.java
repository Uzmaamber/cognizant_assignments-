import java.util.Arrays;
import java.util.Comparator;

class Product {
    int productId;
    String productName;
    String category;

    Product(int id, String name, String cat) {
        productId = id;
        productName = name;
        category = cat;
    }
}

class SearchOperations {

    // Linear Search by productName
    static int linearSearch(Product[] products, String targetName) {
        for (int i = 0; i < products.length; i++) {
            if (products[i].productName.equalsIgnoreCase(targetName)) {
                return i;
            }
        }
        return -1;
    }

    // Sort products alphabetically by productName
    static void sortProductsByName(Product[] products) {
        Arrays.sort(products, Comparator.comparing(p -> p.productName.toLowerCase()));
    }

    // Binary Search by productName (on sorted array)
    static int binarySearch(Product[] products, String targetName) {
        int low = 0, high = products.length - 1;

        while (low <= high) {
            int mid = (low + high) / 2;
            int result = products[mid].productName.compareToIgnoreCase(targetName);

            if (result == 0)
                return mid;
            else if (result < 0)
                low = mid + 1;
            else
                high = mid - 1;
        }
        return -1;
    }
}

public class Main {
    public static void main(String[] args) {
        Product[] products = {
            new Product(1, "Laptop", "Electronics"),
            new Product(2, "Phone", "Electronics"),
            new Product(3, "Shirt", "Clothing"),
            new Product(4, "Book", "Stationery")
        };

        // LINEAR SEARCH
        int index1 = SearchOperations.linearSearch(products, "Phone");
        if (index1 != -1)
            System.out.println("Linear Search -->Found at index: " + index1);
        else
            System.out.println("Linear Search -->Product not found");

        // Sort before BINARY SEARCH
        SearchOperations.sortProductsByName(products);

        int index2 = SearchOperations.binarySearch(products, "Phone");
        if (index2 != -1)
            System.out.println("Binary Search -->Found at index: " + index2);
        else
            System.out.println("Binary Search -->Product not found");
    }
}
