public class FinancialForecast {

    // Recursive method to predict future value
    static double predictFutureValue(double currentValue, double rate, int years) {
        if (years == 0)
            return currentValue;
        return predictFutureValue(currentValue, rate, years - 1) * (1 + rate);
    }

    public static void main(String[] args) {
        double presentValue = 10000;  // Initial amount
        double growthRate = 0.10;     // 10% growth rate
        int years = 5;

        double futureValue = predictFutureValue(presentValue, growthRate, years);
        System.out.printf("Predicted value after %d years: %.2f\n", years, futureValue);
    }
}
