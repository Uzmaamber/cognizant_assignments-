// Main.java
public class Main {
    public static void main(String[] args) {
        // Basic Email notification
        Notifier notifier = new EmailNotifier();

        // Adding SMS and Slack functionalities dynamically
        Notifier multiNotifier = new SlackNotifierDecorator(
                                     new SMSNotifierDecorator(notifier));

        multiNotifier.send("System Alert: Server down .");
    }
}
