public class Main {
    public static void main(String[] args) {
        Image image1 = new ProxyImage("dog.jpg");
        image1.display();  // First time - loads
        image1.display();  // Second time - cached

        System.out.println();

        Image image2 = new ProxyImage("cat.jpg");
        image2.display();  // First time - loads
        image2.display();  // Second time - cached
    }
}
