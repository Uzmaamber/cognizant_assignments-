public class Main {
    public static void main(String[] args) {
        // Building a basic computer
        Computer basicComputer = new Computer.Builder("Intel i3", "4GB")
                .build();

        System.out.println("Basic Computer Specs:");
        basicComputer.showSpecs();

        System.out.println("\n=======================\n");

        // Building a gaming computer
        Computer gamingComputer = new Computer.Builder("Intel i9", "32GB")
                .setStorage("1TB SSD")
                .setGraphicsCard("NVIDIA RTX 4080")
                .build();

        System.out.println("Gaming Computer Specs:");
        gamingComputer.showSpecs();
    }
}
