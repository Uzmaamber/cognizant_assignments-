public class Main {
    public static void main(String[] args) {
        StockMarket stockMarket = new StockMarket();

        Observer mobileApp = new MobileApp();
        Observer webApp = new WebApp();

        stockMarket.registerObserver(mobileApp);
        stockMarket.registerObserver(webApp);

        stockMarket.setStockData("AAPL", 190.50);
        System.out.println("------");
        stockMarket.setStockData("GOOGL", 2810.30);
    }
}
