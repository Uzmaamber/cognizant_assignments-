public class Main {
    public static void main(String[] args) {
        // Create Model
        Student student = new Student("Ayaan", "S101", "A");

        // Create View
        StudentView view = new StudentView();

        // Create Controller
        StudentController controller = new StudentController(student, view);

        // Initial display
        controller.updateView();

        // Update student info
        controller.setStudentName("Uzma Amber");
        controller.setStudentGrade("A+");

        // Display updated info
        controller.updateView();
    }
}
