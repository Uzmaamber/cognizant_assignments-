public class CustomerService {
    private CustomerRepository repository;

    // Constructor Injection
    public CustomerService(CustomerRepository repository) {
        this.repository = repository;
    }

    public void getCustomerInfo(String customerId) {
        String customer = repository.findCustomerById(customerId);
        System.out.println("Retrieved: " + customer);
    }
}
