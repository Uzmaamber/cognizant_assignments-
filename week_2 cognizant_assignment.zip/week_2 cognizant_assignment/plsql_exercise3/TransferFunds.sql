CREATE OR REPLACE PROCEDURE TransferFunds(
  from_acct IN NUMBER,
  to_acct IN NUMBER,
  amount IN NUMBER
) AS
  from_balance NUMBER;
BEGIN
  -- Get current balance of source account
  SELECT balance INTO from_balance
  FROM accounts
  WHERE account_id = from_acct;

  IF from_balance >= amount THEN
    UPDATE accounts SET balance = balance - amount WHERE account_id = from_acct;
    UPDATE accounts SET balance = balance + amount WHERE account_id = to_acct;
    DBMS_OUTPUT.PUT_LINE('₹' || amount || ' transferred from Account ' || from_acct || ' to ' || to_acct);
    COMMIT;
  ELSE
    DBMS_OUTPUT.PUT_LINE(' Transfer failed: Insufficient balance in Account ' || from_acct);
  END IF;
END;
/
