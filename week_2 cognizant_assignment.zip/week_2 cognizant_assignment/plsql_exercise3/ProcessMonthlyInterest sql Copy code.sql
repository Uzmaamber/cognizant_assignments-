CREATE OR REPLACE PROCEDURE ProcessMonthlyInterest AS
BEGIN
  FOR rec IN (
    SELECT account_id, balance
    FROM accounts
    WHERE LOWER(account_type) = 'savings'
  ) LOOP
    UPDATE accounts
    SET balance = rec.balance + (rec.balance * 0.01)
    WHERE account_id = rec.account_id;

    DBMS_OUTPUT.PUT_LINE(' Interest applied to Account ' || rec.account_id);
  END LOOP;
  COMMIT;
END;
/
