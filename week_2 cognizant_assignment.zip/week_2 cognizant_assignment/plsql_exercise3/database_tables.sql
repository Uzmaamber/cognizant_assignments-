CREATE TABLE accounts (
  account_id   NUMBER PRIMARY KEY,
  customer_id  NUMBER,
  account_type VARCHAR2(20), -- e.g., 'Savings'
  balance      NUMBER(10, 2)
);

INSERT INTO accounts VALUES (1, 101, 'Savings', 10000);
INSERT INTO accounts VALUES (2, 102, 'Savings', 7500);
INSERT INTO accounts VALUES (3, 103, 'Current', 5000);
INSERT INTO accounts VALUES (4, 104, 'Savings', 12000);
COMMIT;

CREATE TABLE employees (
  emp_id     NUMBER PRIMARY KEY,
  name       VARCHAR2(50),
  department VARCHAR2(50),
  salary     NUMBER(10, 2)
);

INSERT INTO employees VALUES (1, 'Uzma', 'Finance', 40000);
INSERT INTO employees VALUES (2, 'Aliya', 'IT', 50000);
INSERT INTO employees VALUES (3, 'Ravi', 'Finance', 45000);
COMMIT;
