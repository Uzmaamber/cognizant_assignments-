CREATE OR REPLACE PROCEDURE UpdateEmployeeBonus(
  dept_name IN VARCHAR2,
  bonus_percent IN NUMBER
) AS
BEGIN
  FOR rec IN (
    SELECT emp_id, salary
    FROM employees
    WHERE department = dept_name
  ) LOOP
    UPDATE employees
    SET salary = rec.salary + (rec.salary * bonus_percent / 100)
    WHERE emp_id = rec.emp_id;

    DBMS_OUTPUT.PUT_LINE(' Bonus added for Employee ' || rec.emp_id);
  END LOOP;
  COMMIT;
END;
/
