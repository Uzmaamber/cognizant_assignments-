-- Exercise 1: Discount for customers above 60
BEGIN
  FOR rec IN (
    SELECT l.loan_id, l.interest_rate
    FROM customers c
    JOIN loans l ON c.customer_id = l.customer_id
    WHERE c.age > 60
  ) LOOP
    UPDATE loans
    SET interest_rate = rec.interest_rate - 1
    WHERE loan_id = rec.loan_id;

    DBMS_OUTPUT.PUT_LINE('✅ Discount applied to Loan ' || rec.loan_id ||
                         ': New rate = ' || (rec.interest_rate - 1));
  END LOOP;
  COMMIT;
END;
/

-- Exercise 2: Set IsVIP to TRUE for balance > 10000
BEGIN
  FOR rec IN (
    SELECT customer_id
    FROM customers
    WHERE balance > 10000 AND NVL(isvip, 'N') = 'N'
  ) LOOP
    UPDATE customers
    SET isvip = 'Y'
    WHERE customer_id = rec.customer_id;

    DBMS_OUTPUT.PUT_LINE('🏅 Customer ' || rec.customer_id || ' promoted to VIP!');
  END LOOP;
  COMMIT;
END;
/

-- Exercise 3: Reminders for loans due in next 30 days
BEGIN
  FOR rec IN (
    SELECT l.loan_id, l.due_date, c.name
    FROM loans l
    JOIN customers c ON c.customer_id = l.customer_id
    WHERE l.due_date BETWEEN SYSDATE AND SYSDATE + 30
  ) LOOP
    DBMS_OUTPUT.PUT_LINE('📢 Reminder: Loan ' || rec.loan_id ||
                         ' for ' || rec.name ||
                         ' is due on ' || TO_CHAR(rec.due_date, 'DD-Mon-YYYY'));
  END LOOP;
END;
/
